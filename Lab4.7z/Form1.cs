﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;

namespace Lab4
{
    public partial class Form1 : Form
    {

        public string text_file="E:\\input.txt";
        public string xml_file = "E:\\input.xml";
        List<Train> trains;
        List<Passanger> passangers;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Program1.prepareXml(xml_file);
            trains = Program1.parseXml(xml_file);
            foreach (var t in trains) richTextBox2.Text += t.ToString() + "\n";
            richTextBox2.Text += "\nPassangers\n";
            passangers = Program1.parseText(text_file);
            foreach (var p in passangers) richTextBox2.Text += p.ToString() + "\n";

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Passanger need = new Passanger() ;
            List<Train> needTrains = new List<Train>();
            foreach(var p in passangers)
            {
                if (p.name == textBox1.Text)
                {
                    need = p;
                }
            }
            DateTime date;
            richTextBox2.Text = "";
            if (textBox2.Text == "yyyy/mm/dd") date = DateTime.Now;
            else if (textBox2.Text != "")
            {
                string[] parsingTime = textBox2.Text.Split('/');
                date = new DateTime(Convert.ToInt32(parsingTime[0]), Convert.ToInt32(parsingTime[1]), Convert.ToInt32(parsingTime[2]));
            }
            else date = DateTime.Now;
            bool dep = false;
            bool arr = false;
            DateTime depT = new DateTime();
            foreach (var train in trains)
            {
                foreach (var c in train.route)
                {
                    if (c.city == need.from && c.departure > date)
                    {
                        dep = true;
                        depT = c.departure;
                    }
                    if (c.city == need.to && c.arrival > date) arr = true;
                }
                if (arr && dep && depT>date) 
                {
                    richTextBox2.Text+=(train.ToString())+'\n';
                    needTrains.Add(train);
                    dep = false;
                    arr = false;
                    depT = new DateTime();
                }
            }
            if (needTrains.Count != 0)
            {
                string minTrain = "";
                DateTime minTime = new DateTime(9999, 12, 30);
                foreach (var t in needTrains)
                {
                    for (int i = 0; i < t.route.Count; i++)
                    {
                        if (t.route[i].city == need.to)
                        {
                            if (t.route[i].arrival < minTime) {
                                minTime = t.route[i].arrival;
                                minTrain = t.number;
                            }
                        }
                    }
                }
                richTextBox2.Text += "\nRecommended Train: " + minTrain;
            }
            else
            {
                richTextBox2.Text = "No matches";
            }
           
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            richTextBox2.Text = " ";
            textBox1.Text = "Name";
            textBox2.Text = "yyyy/mm/dd";
            foreach (var t in trains) richTextBox2.Text += t.ToString() + "\n";
            richTextBox2.Text += "\nPassangers\n";
            foreach (var p in passangers) richTextBox2.Text += p.ToString() + "\n";
        }
    }
    class Station
    {
        public string city = "";
        public DateTime departure = new DateTime();
        public DateTime arrival = new DateTime();
        public Station() { }

        //Конструктор, если станция является промежуточной
        public Station(DateTime arrival, string city, DateTime departure)
        {
            this.city = city;
            this.departure = departure;
            this.arrival = arrival;
        }

        //Конструктор, если город является конечным пунктом
        public Station(DateTime arrival, string city)
        {
            this.arrival = arrival;
            this.city = city;
        }

        //Конструктор, если город является стартовой точкой
        public Station(string city, DateTime departure)
        {
            this.city = city;
            this.departure = departure;
        }

        //Метод для удобного вывода
        public override string ToString()
        {
            string s = "";
            DateTime start = new DateTime(); //Отсчёт с нулевой секунды
            s += "City: " + this.city;
            if (arrival != start)
            {
                s += ". Arrive at: " + this.arrival.ToString();
            }
            if (departure != start)
            {
                s += ". Depart at: " + this.departure.ToString();
            }
            return s;
        }
    }

    class Train
    {
        delegate string Operation(List<Station> temp);
        public string number = "";
        public string departureCity = "";
        public DateTime departure = new DateTime();
        public string arrivalCity = "";
        public DateTime arrival = new DateTime();
        public List<Station> route = new List<Station>();

        public Train() { }

        public Train(string number, string departureCity, DateTime departure, string arrivalCity, DateTime arrival, List<Station> route)
        {
            this.number = number;
            this.departure = departure;
            this.departureCity = departureCity;
            this.arrivalCity = arrivalCity;
            this.arrival = arrival;
            this.route = route;
        }

        public override string ToString()
        {
            string s = "";
            s += "Train number: " + this.number + "\nStarts from: " + departureCity + "\n\tat " + departure +
                "\nTo: " + arrivalCity + "\n\tat: " + arrival + "\nVisits: \n";
            foreach (var testc in this.route)
            {
                s += "\t" + testc.ToString() + "\n";
            }
            return s;
        }
    }

    class Program1
    {
        public static DateTime toDate(string time)
        {
            string[] times = time.Split('-', 'T', ':');
            List<int> input = new List<int>();
            foreach (string t in times) input.Add(Convert.ToInt32(t));
            return new DateTime(input[0], input[1], input[2], input[3], input[4], input[5]);
        }
        public static List<Train> parseXml(string file)
        {
            List<Train> ret = new List<Train>();
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(file);
            XmlElement xRoot = xDoc.DocumentElement;
            foreach (XmlNode node1 in xRoot)
            {
                if (node1.Name == "Train")
                {
                    Train a = new Train();
                    a.number = node1.Attributes[0].Value;
                    foreach (XmlNode node in node1.ChildNodes)
                    {
                        if (node.Name == "Departure")
                        {
                            a.departure = toDate(node.InnerText);
                        }
                        if (node.Name == "Arrival")
                        {
                            a.arrival = toDate(node.InnerText);
                        }
                        if (node.Name == "DepartureCity")
                        {
                            a.departureCity = node.InnerText;
                        }
                        if (node.Name == "ArrivalCity")
                            a.arrivalCity = node.InnerText;
                        if (node.Name == "Route")
                        {
                            List<Station> stops = new List<Station>();
                            foreach (XmlNode item1 in node.ChildNodes)
                            {
                                Station stop = new Station();
                                if (item1.Name == "Item")
                                {
                                    foreach (XmlNode item in item1.ChildNodes)
                                    {
                                        if (item.Name == "City") stop.city = item.InnerText; /*city += item.InnerText;*/
                                        if (item.Name == "Departure") stop.departure = toDate(item.InnerText); /*departure += item.InnerText;*/
                                        if (item.Name == "Arrival") stop.arrival = toDate(item.InnerText); /*arrival += item.InnerText;*/
                                    }
                                    stops.Add(stop);
                                }
                            }
                            a.route = stops;
                        }
                    }
                    ret.Add(a);
                }
            }
            return ret;
        }
        public static void prepareXml(string file)
        {
            List<string> text = new List<string>();
            int counter = 0;
            string line;

            System.IO.StreamReader files =
                new System.IO.StreamReader(file);
            while ((line = files.ReadLine()) != null)
            {
                if (line.Contains("<TrainList>")) return;
                text.Add(line);
                counter++;
            }
            files.Close();
            text.Insert(1, "<TrainList>");
            text.Insert(counter + 1, "</TrainList>");
            System.IO.StreamWriter sw = new System.IO.StreamWriter(file, false);
            for (int i = 0; i < text.Count; i++)
            {
                sw.WriteLine(text[i]);
            }
            sw.Close();
        }
        public static List<Passanger> parseText(string file)
        {
            List<Passanger> passangers = new List<Passanger>();
            System.IO.StreamReader text = new System.IO.StreamReader(file);
            string line;
            while ((line = text.ReadLine()) != null)
            {
                Passanger a = new Passanger();
                if (line[line.Length - 1] == ' ') line.Remove(line.Length - 1);
                a.name = line;
                line = text.ReadLine();
                if (line[line.Length - 1] == ' ') line.Remove(line.Length - 1);
                a.from = line;
                line = text.ReadLine();
                if (line[line.Length - 1] == ' ') line.Remove(line.Length - 1);
                a.to = line;
                passangers.Add(a);
            }
            return passangers;
        }
    }
    class Passanger
    {
        public string name = "";
        public string from = "";
        public string to = "";
        public Passanger(string name, string from, string to)
        {
            this.name = name;   
            this.from = from;
            this.to = to;
        }
        public override string ToString()
        {
            string s = "";
            s+=this.name+" to: "+this.to+" from: "+this.from;
            return s;
        }
        public Passanger() { }
    }
}
